



while True:
    nomre = float(input("Nomre ra vared konid: "))


    if nomre < 0 or nomre > 20:
        print("Error")
        continue

    if nomre >= 17 and nomre <= 20:
        if nomre >= 19.5:
            print("A++")
        elif nomre >= 18:
            print("A+")
        else:
            print("A")

    elif nomre >= 14 and nomre < 17:
        if nomre >= 16:
            print("B++")
        elif nomre >= 15:
            print("B+")
        else:
            print("B")

    elif nomre >= 11 and nomre < 14:
        if nomre >= 13:
            print("C++")
        elif nomre >= 12:
            print("C+")
        else:
            print("C")

    elif nomre >= 8 and nomre < 11:
        if nomre >= 10:
            print("D++")
        elif nomre >= 9:
            print("D+")
        else:
            print("D")

    else:
        print("Ridi")
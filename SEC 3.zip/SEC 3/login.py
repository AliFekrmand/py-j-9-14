



while True:

    username = input("Username ra vared kon: ")
    password = input("Password ra vared kon: ")

    if len(password) > 10:
        print("Password toolanie")
        continue

    if username != "Alinegrow" and password != "Aa123456":
        print("Joftesh eshtebah ast")
        continue

    elif username != "Alinegrow":
        print("Username eshtebah ast")
        continue

    elif password != "Aa123456":
        print("Password eshtebah ast")
        continue

    sen = int(input("Sen ra vared kon: "))

    if sen < 16:
        print("Bozorg shodi, dobare emtehan kon")
        continue

    else:
        print("Login")
        break
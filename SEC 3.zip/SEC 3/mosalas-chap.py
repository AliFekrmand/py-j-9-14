




for i in range(1, 10):
    for j in range(1, 10):

        if j == 9 or (i <= 5 and j == 10-i) or (i > 5 and j == i):
            print("*", end=" ")
        else:
            print(" ", end=" ")

    print()
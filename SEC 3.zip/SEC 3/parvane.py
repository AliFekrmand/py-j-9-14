




for i in range(1, 5):
    for j in range(1, 14):

        if j == 1 or j == 13 or j == 2*i-1 or j == 15-2*i:
            print("*", end=" ")
        else:
            print(" ", end=" ")

    print()

for i in range(3, 0, -1):
    for j in range(1, 14):

        if j == 1 or j == 13 or j == 2*i-1 or j == 15-2*i:
            print("*", end=" ")
        else:
            print(" ", end=" ")

    print()





for i in range(1, 10):
    for j in range(1, 10):

        if j == 1 or (i <= 5 and j == 2*i-1) or (i > 5 and j == 19-2*i):
            print("*", end=" ")
        else:
            print(" ", end=" ")

    print()




while True:
    hoghoogh = int(input("Hoghoogh ra vared konid: "))

    if hoghoogh == 0:
        break

    if hoghoogh > 200 or hoghoogh < 5:
        print("Error")
        continue

    if hoghoogh >= 100:
        hoghoogh = hoghoogh * 0.65
    elif hoghoogh >= 90:
        hoghoogh = hoghoogh * 0.80
    elif hoghoogh >= 70:
        hoghoogh = hoghoogh * 0.85
    elif hoghoogh >= 60:
        hoghoogh = hoghoogh * 0.90
    elif hoghoogh >= 50:
        hoghoogh = hoghoogh * 0.95
    elif hoghoogh >= 40:
        hoghoogh = hoghoogh * 0.97
    elif hoghoogh >= 30:
        hoghoogh = hoghoogh * 0.98

    print("Hoghoogh pardakhti:", hoghoogh)